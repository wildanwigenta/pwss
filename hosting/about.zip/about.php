<!DOCTYPE html>
<html>
<head>
    <title>Tentang Saya</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Halaman Tentang</h1>
    <p>Website ini dibuat oleh kelompok G untuk tugas pwss.</p>
    <a href="index.php">Beranda</a> | <a href="contact.php">Kontak</a>
</body>
</html>

