<!DOCTYPE html>
<html>
<head>
    <title>Selamat Datang</title>
</head>
<body>
    <h1>Halo, ini adalah halaman utama untuk tugas pwss</h1>
    <p><a href="about.php">Tentang</a> | <a href="contact.php">Kontak</a></p>
</body>
</html>
